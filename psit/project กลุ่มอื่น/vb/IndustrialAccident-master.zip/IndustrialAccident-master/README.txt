This repository is for PSIT project about Industrial Accident
P.S.I'm Napon Tunglukmongkol 60070037 have commited all the codes first because the
other in this group don't know how to use git hub so I commit the codes first for 
showing progessing in case of anyone come in and see this repository the reason that
the other don't know how to use git hub is because I didn't teach them and forgot to teach them